#!/usr/bin/env python3
"""
Apex Autonomous Viral Clipper & Shorts Generator
=================================================
Automates the clipping workflow for Clipping.net, TikTok, and YouTube Shorts:
1. Downloads targeted viral segments via yt-dlp.
2. Reframes 16:9 landscape to 9:16 vertical (1080x1920) with soft blurred backdrop.
3. Overlays viral high-converting hook banner.
4. Generates optimized title, description, and tags for maximum reach.
"""

import os
import sys
import argparse
import subprocess
import json
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = BASE_DIR / "output"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

def run_cmd(cmd, check=True):
    print(f"[*] Executing: {cmd}")
    res = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if check and res.returncode != 0:
        print(f"[!] Command failed: {res.stderr}")
        raise RuntimeError(res.stderr)
    return res

def download_segment(url, start_time, end_time, raw_output_path):
    """Downloads an exact time slice of a video using yt-dlp."""
    print(f"[*] Downloading segment {start_time} -> {end_time} from {url}...")
    section = f"*{start_time}-{end_time}"
    cmd = (
        f'yt-dlp --download-sections "{section}" '
        f'-f "bestvideo[height<=1080]+bestaudio/best[height<=1080]" '
        f'--force-keyframes-at-cuts '
        f'-o "{raw_output_path}" "{url}"'
    )
    run_cmd(cmd)
    files = list(Path(raw_output_path).parent.glob(Path(raw_output_path).stem + ".*"))
    if files:
        return str(files[0])
    return raw_output_path

def generate_overlay_image(hook_title, sub_title, output_png_path):
    """Generates a professional 1080x1920 transparent PNG overlay with SVG + sips."""
    clean_hook = hook_title.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    clean_sub = sub_title.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    
    svg_content = f'''<svg width="1080" height="1920" xmlns="http://www.w3.org/2000/svg">
  <!-- Top Hook Header Box -->
  <rect x="50" y="180" width="980" height="150" rx="28" fill="#0c0e17" fill-opacity="0.92" stroke="#FFD700" stroke-width="6"/>
  <text x="540" y="275" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif" font-size="44" font-weight="900" fill="#FFFFFF" text-anchor="middle">{clean_hook}</text>
'''
    if clean_sub:
        svg_content += f'''
  <!-- Bottom Call to Action Banner -->
  <rect x="90" y="1650" width="900" height="100" rx="22" fill="#0c0e17" fill-opacity="0.9" stroke="#00E5FF" stroke-width="4"/>
  <text x="540" y="1715" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif" font-size="34" font-weight="700" fill="#00E5FF" text-anchor="middle">{clean_sub}</text>
'''
    svg_content += '</svg>'
    
    svg_path = Path(output_png_path).with_suffix(".svg")
    with open(svg_path, "w", encoding="utf-8") as f:
        f.write(svg_content)
        
    cmd = f'sips -s format png "{svg_path}" --out "{output_png_path}" > /dev/null 2>&1'
    run_cmd(cmd)
    return output_png_path

def create_vertical_short(input_video, output_video, hook_title="TOP SECRET REVEALED", subtitle_text=""):
    """
    Reframes 16:9 horizontal video into 1080x1920 vertical layout with:
    - Layer 1: Blurred, scaled background filling 1080x1920
    - Layer 2: Centered sharp foreground video
    - Layer 3: Native SVG vector graphics overlay (hook badge & sub banner)
    """
    print(f"[*] Processing vertical short: {input_video} -> {output_video}")
    overlay_png = Path(output_video).parent / f"{Path(output_video).stem}_overlay.png"
    generate_overlay_image(hook_title, subtitle_text, str(overlay_png))

    filter_complex = (
        "[0:v]split=2[bg_in][fg_in];"
        "[bg_in]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,boxblur=20:10[bg];"
        "[fg_in]scale=1080:-2[fg];"
        "[bg][fg]overlay=0:(1920-h)/2[v_base];"
        "[v_base][1:v]overlay=0:0[v_out]"
    )

    cmd = (
        f'ffmpeg -y -i "{input_video}" -i "{overlay_png}" '
        f'-filter_complex "{filter_complex}" '
        f'-map "[v_out]" -map 0:a? '
        f'-c:v libx264 -preset fast -crf 20 -c:a aac -b:a 192k '
        f'"{output_video}"'
    )
    run_cmd(cmd)
    print(f"[✓] Created vertical viral short: {output_video}")
    return output_video

def generate_social_metadata(title, hook, clip_name):
    """Creates ready-to-copy metadata file for YouTube Shorts & TikTok upload."""
    meta = {
        "title": f"{hook} 🤯 #shorts #ai #technology #podcast",
        "description": (
            f"Key insights from {title}.\n\n"
            f"💡 What do you think about this? Comment your thoughts below!\n\n"
            f"👉 Download the 2026 AI Automation Blueprint: https://apexstan-vault.loca.lt/store.html\n\n"
            f"#shorts #samaltman #lexfridman #artificialintelligence #tech #wealth #future #podcastclips"
        ),
        "tags": ["shorts", "podcast clips", "sam altman", "lex fridman", "ai", "artificial intelligence", "tech news", "future of work", "clipping", "viral"],
        "recommended_thumbnail_time": "00:00:03"
    }
    meta_path = OUTPUT_DIR / f"{clip_name}_metadata.json"
    with open(meta_path, "w") as f:
        json.dump(meta, f, indent=2)
    print(f"[✓] Metadata saved: {meta_path}")
    return meta

def main():
    parser = argparse.ArgumentParser(description="Apex Viral Auto-Clipper")
    parser.add_argument("--url", type=str, default="https://www.youtube.com/watch?v=jvqFAi7vkBc", help="YouTube video URL")
    parser.add_argument("--start", type=str, default="00:00:15", help="Start timestamp (HH:MM:SS)")
    parser.add_argument("--end", type=str, default="00:01:05", help="End timestamp (HH:MM:SS)")
    parser.add_argument("--hook", type=str, default="COMPUTE IS THE NEW CURRENCY", help="Hook text at top")
    parser.add_argument("--sub", type=str, default="Sam Altman on Lex Fridman #419", help="Sub-caption at bottom")
    parser.add_argument("--name", type=str, default="sam_altman_compute_currency", help="Output file base name")
    parser.add_argument("--local-input", type=str, default=None, help="Use existing local video file instead of downloading")
    args = parser.parse_args()

    raw_path = OUTPUT_DIR / f"{args.name}_raw.mp4"
    final_output = OUTPUT_DIR / f"{args.name}_vertical_short.mp4"

    if args.local_input and Path(args.local_input).exists():
        input_vid = args.local_input
    else:
        input_vid = download_segment(args.url, args.start, args.end, str(raw_path))

    create_vertical_short(input_vid, str(final_output), args.hook, args.sub)
    generate_social_metadata("Sam Altman Lex Fridman Podcast", args.hook, args.name)
    print(f"\n=======================================================")
    print(f"🎉 CLIP COMPLETE & READY TO POST!")
    print(f"Output File: {final_output}")
    print(f"=======================================================")

if __name__ == "__main__":
    main()
