#!/usr/bin/env python3
"""
Apex Split-Screen Viral Short Generator (Viblo Clone Mode 1)
============================================================
Creates high-retention 9:16 split-screen videos:
- Top Half (1080x960): Speaker / Podcast / Reaction Video
- Bottom Half (1080x960): Engaging B-Roll / Satisfying Gameplay Loop
- Center Divider: Glowing neon or gold separator with custom badge
- Top Hook Header: High-impact curiosity title
"""

import os
import sys
import argparse
import subprocess
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = BASE_DIR / "output"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

def run_cmd(cmd):
    print(f"[*] Executing: {cmd}")
    res = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if res.returncode != 0:
        print(f"[!] Error: {res.stderr}")
        raise RuntimeError(res.stderr)
    return res

def generate_split_overlay(hook_title, cta_text, output_png_path):
    """Generates an SVG vector divider + hook header and rasterizes with sips."""
    clean_hook = hook_title.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    clean_cta = cta_text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    
    svg = f'''<svg width="1080" height="1920" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="dividerGrad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#FF007A" stop-opacity="0.2"/>
      <stop offset="50%" stop-color="#FFD700" stop-opacity="1"/>
      <stop offset="100%" stop-color="#00F0FF" stop-opacity="0.2"/>
    </linearGradient>
    <filter id="glow">
      <feGaussianBlur stdDeviation="6" result="coloredBlur"/>
      <feMerge>
        <feMergeNode in="coloredBlur"/>
        <feMergeNode in="SourceGraphic"/>
      </feMerge>
    </filter>
  </defs>

  <!-- Top Hook Header Box -->
  <rect x="50" y="80" width="980" height="130" rx="24" fill="#0b0e14" fill-opacity="0.94" stroke="#FFD700" stroke-width="5"/>
  <text x="540" y="162" font-family="-apple-system, BlinkMacSystemFont, Arial, sans-serif" font-size="40" font-weight="900" fill="#FFFFFF" text-anchor="middle">{clean_hook}</text>

  <!-- Center Glowing Split Divider -->
  <line x1="20" y1="960" x2="1060" y2="960" stroke="url(#dividerGrad)" stroke-width="8" filter="url(#glow)"/>
  <circle cx="540" cy="960" r="28" fill="#0b0e14" stroke="#FFD700" stroke-width="4"/>
  <text x="540" y="969" font-family="-apple-system, BlinkMacSystemFont, Arial, sans-serif" font-size="24" font-weight="900" fill="#FFD700" text-anchor="middle">VS</text>
'''
    if clean_cta:
        svg += f'''
  <!-- Bottom Engagement Pill -->
  <rect x="120" y="1740" width="840" height="90" rx="24" fill="#0b0e14" fill-opacity="0.9" stroke="#00F0FF" stroke-width="3"/>
  <text x="540" y="1796" font-family="-apple-system, BlinkMacSystemFont, Arial, sans-serif" font-size="32" font-weight="700" fill="#00F0FF" text-anchor="middle">{clean_cta}</text>
'''
    svg += '</svg>'
    
    svg_path = Path(output_png_path).with_suffix(".svg")
    with open(svg_path, "w", encoding="utf-8") as f:
        f.write(svg)
    run_cmd(f'sips -s format png "{svg_path}" --out "{output_png_path}" > /dev/null 2>&1')
    return output_png_path

def create_split_screen_video(top_video, bottom_video, output_path, hook="WAIT TILL YOU SEE THIS 🤯", cta="Subscribe for Part 2"):
    """
    Stacks top_video and bottom_video into 1080x1920:
    - Top: 1080x960
    - Bottom: 1080x960
    - Overlay: Center divider & hook badges
    - Audio: Uses top video's primary audio stream
    """
    print(f"[*] Creating Split-Screen Video: {output_path}")
    overlay_png = Path(output_path).parent / f"{Path(output_path).stem}_split_overlay.png"
    generate_split_overlay(hook, cta, str(overlay_png))

    # Complex filter:
    # Scale & crop top to 1080x960
    # Scale & crop bottom to 1080x960
    # Stack vertically: vstack
    # Overlay graphic elements
    filter_complex = (
        "[0:v]scale=1080:960:force_original_aspect_ratio=increase,crop=1080:960[top];"
        "[1:v]scale=1080:960:force_original_aspect_ratio=increase,crop=1080:960[bottom];"
        "[top][bottom]vstack[stacked];"
        "[stacked][2:v]overlay=0:0[v_out]"
    )

    cmd = (
        f'ffmpeg -y -i "{top_video}" -stream_loop -1 -i "{bottom_video}" -i "{overlay_png}" '
        f'-filter_complex "{filter_complex}" '
        f'-map "[v_out]" -map 0:a? '
        f'-c:v libx264 -preset fast -crf 20 -c:a aac -b:a 192k -shortest '
        f'"{output_path}"'
    )
    run_cmd(cmd)
    print(f"[✓] Split-screen short created successfully: {output_path}")
    return output_path

def main():
    parser = argparse.ArgumentParser(description="Viblo Split-Screen Generator")
    parser.add_argument("--top", required=True, help="Path to top video (speaker/reaction)")
    parser.add_argument("--bottom", required=True, help="Path to bottom video (gameplay/satisfying b-roll)")
    parser.add_argument("--hook", default="HOW TO SCALE TO $10K/MO 🚀", help="Top hook text")
    parser.add_argument("--cta", default="Follow @ApexEmpire for Blueprint", help="Bottom CTA text")
    parser.add_argument("--out", default="split_screen_short.mp4", help="Output filename")
    args = parser.parse_args()

    out_file = OUTPUT_DIR / args.out
    create_split_screen_video(args.top, args.bottom, str(out_file), args.hook, args.cta)

if __name__ == "__main__":
    main()
