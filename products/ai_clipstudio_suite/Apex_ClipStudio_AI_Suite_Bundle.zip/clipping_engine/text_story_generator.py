#!/usr/bin/env python3
"""
Apex Fake Text Story & Chat Drama Generator (Viblo Clone Mode 2)
================================================================
Generates viral animated text conversations (iMessage / WhatsApp style)
superimposed over engaging background footage (gameplay / satisfying loops).
One of the highest-CPM and most viral formats on TikTok and YouTube Shorts.
"""

import os
import sys
import json
import argparse
import subprocess
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = BASE_DIR / "output"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

def run_cmd(cmd):
    print(f"[*] Executing: {cmd}")
    res = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if res.returncode != 0:
        print(f"[!] Error: {res.stderr}")
        raise RuntimeError(res.stderr)
    return res

def render_chat_frame_svg(contact_name, messages, output_png):
    """
    Renders an authentic iOS iMessage interface as a 1080x1920 transparent PNG:
    - Top header: Contact Avatar, Name, FaceTime/Audio icons
    - Message list: Clean gray (incoming) and blue/green (outgoing) bubbles
    """
    svg = f'''<svg width="1080" height="1920" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <filter id="shadow" x="-5%" y="-5%" width="110%" height="110%">
      <feDropShadow dx="0" dy="8" stdDeviation="12" flood-color="#000000" flood-opacity="0.45"/>
    </filter>
  </defs>

  <!-- iOS Top Contact Bar Card -->
  <rect x="60" y="80" width="960" height="150" rx="36" fill="#16181F" fill-opacity="0.95" stroke="#2D313E" stroke-width="2" filter="url(#shadow)"/>
  <circle cx="150" cy="155" r="42" fill="#3B82F6"/>
  <text x="150" y="167" font-family="-apple-system, BlinkMacSystemFont, Arial, sans-serif" font-size="34" font-weight="900" fill="#FFFFFF" text-anchor="middle">{contact_name[0] if contact_name else "U"}</text>
  <text x="220" y="148" font-family="-apple-system, BlinkMacSystemFont, Arial, sans-serif" font-size="36" font-weight="bold" fill="#FFFFFF">{contact_name}</text>
  <text x="220" y="184" font-family="-apple-system, BlinkMacSystemFont, Arial, sans-serif" font-size="24" fill="#9CA3AF">iMessage • Today</text>

  <!-- Messages Container -->
  <g id="messages" filter="url(#shadow)">
'''
    current_y = 280
    for msg in messages:
        text = msg.get("text", "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        is_me = msg.get("is_me", False)
        bubble_width = min(820, max(260, len(text) * 22 + 70))
        bubble_height = 80 if len(text) < 35 else 125
        
        if is_me:
            # Outgoing Blue Bubble (Right aligned)
            bx = 1020 - bubble_width
            bubble_fill = "#007AFF"
            text_fill = "#FFFFFF"
        else:
            # Incoming Dark Gray Bubble (Left aligned)
            bx = 60
            bubble_fill = "#2C2C2E"
            text_fill = "#FFFFFF"
            
        svg += f'''
    <rect x="{bx}" y="{current_y}" width="{bubble_width}" height="{bubble_height}" rx="28" fill="{bubble_fill}"/>
    <text x="{bx + 32}" y="{current_y + 48}" font-family="-apple-system, BlinkMacSystemFont, Arial, sans-serif" font-size="32" font-weight="500" fill="{text_fill}">{text}</text>
'''
        current_y += bubble_height + 25

    svg += '''  </g>
</svg>'''

    svg_file = Path(output_png).with_suffix(".svg")
    with open(svg_file, "w", encoding="utf-8") as f:
        f.write(svg)
    run_cmd(f'sips -s format png "{svg_file}" --out "{output_png}" > /dev/null 2>&1')
    return output_png

def create_text_story_video(background_video, script_json_path, output_mp4):
    """
    Generates a full viral text story video by overlaying timed chat bubbles over background gameplay.
    """
    with open(script_json_path, "r") as f:
        data = json.load(f)

    contact = data.get("contact", "Unknown")
    messages = data.get("messages", [])

    print(f"[*] Rendering Text Story for: {contact} with {len(messages)} messages")
    overlay_png = OUTPUT_DIR / f"{Path(output_mp4).stem}_chat_overlay.png"
    render_chat_frame_svg(contact, messages, str(overlay_png))

    # Scale background to 1080x1920 9:16 and overlay chat interface
    filter_complex = (
        "[0:v]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920[bg];"
        "[bg][1:v]overlay=0:0[v_out]"
    )

    cmd = (
        f'ffmpeg -y -i "{background_video}" -i "{overlay_png}" '
        f'-filter_complex "{filter_complex}" '
        f'-map "[v_out]" -map 0:a? '
        f'-c:v libx264 -preset fast -crf 20 -c:a aac -b:a 192k -t 15 '
        f'"{output_mp4}"'
    )
    run_cmd(cmd)
    print(f"[✓] Created Text Story Video: {output_mp4}")
    return output_mp4

def main():
    parser = argparse.ArgumentParser(description="Viblo Text Story Generator")
    parser.add_argument("--bg", required=True, help="Background video path (gameplay/satisfying)")
    parser.add_argument("--script", required=True, help="Path to chat conversation JSON script")
    parser.add_argument("--out", default="viral_text_story.mp4", help="Output video filename")
    args = parser.parse_args()

    out_file = OUTPUT_DIR / args.out
    create_text_story_video(args.bg, args.script, str(out_file))

if __name__ == "__main__":
    main()
